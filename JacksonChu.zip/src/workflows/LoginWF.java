package workflows;

import org.openqa.selenium.WebDriver;

import pages.InvoiceListPage;
import pages.LoginPage;

public class LoginWF {
	
	WebDriver webDriver;
	
	public LoginWF(WebDriver webDriver)
	{
		this.webDriver = webDriver;
	}
	
	public String login (String user, String password) throws Exception {
		LoginPage login = new LoginPage(webDriver);
		InvoiceListPage list = new InvoiceListPage(webDriver);
		
		login.waitLoad(15000);
		
		login.setUsername(user);
		login.setPassword(password);
		
		login.clickLogin();
		
		if (list.exists(5000)) {
			return "Successfully logged in.";
		}
		else if (login.getAlert().equals("Wrong username or password."))
		{
			return "Wrong username or password.";
		}
		
		throw new Exception("Unknown issue, did not logged in, but did not get wrong login message.");
		
	}
	
}
