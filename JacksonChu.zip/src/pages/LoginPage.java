package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	
	WebDriver webDriver;
	
	
	public LoginPage(WebDriver webDriver)
	{
		this.webDriver = webDriver;
	}
	
	private WebElement header()
	{
		WebElement h1 = webDriver.findElement(By.xpath("//div[@class='col text-center']//h1"));
		return h1;
	}
	
	private WebElement usernameField()
	{
		WebElement input = webDriver.findElement(By.xpath("//input[@name='username']"));
		return input;
	}

	private WebElement passwordField()
	{
		WebElement input = webDriver.findElement(By.xpath("//input[@name='password']"));
		return input;
	}
	
	private WebElement loginButton()
	{
		WebElement button = webDriver.findElement(By.xpath("//button[@id='btnLogin']"));
		return button;
	}
	
	private WebElement alertDiv ()
	{
		WebElement div = webDriver.findElement(By.xpath("//div[@role='alert']"));
		return div;
	}
	
	public String getHeader()
	{
		return header().getText();
	}
	
	public String getUsername()
	{
		return usernameField().getAttribute("value");
	}
	
	public void setUsername(String username) {
		usernameField().sendKeys(username);
	}
	
	public String getPassword()
	{
		return passwordField().getAttribute("value");
	}
	
	public void setPassword(String password) {
		passwordField().sendKeys(password);
	}
	
	public void clickLogin()
	{
		loginButton().click();
	}
	
	public String getAlert()
	{
		return alertDiv().getText();
	}
	
	public void waitLoad(int millis)
	{
		if (!exists(millis))
		{
			throw new TimeoutException("Login Page did not load after " + millis + " milliseconds.");
		}
	}
	
	public boolean exists(int millis)
	{
		long end = System.currentTimeMillis() + millis;
		while(System.currentTimeMillis() < end)
		{
			if (exists())
			{
				return true;
			}
			
		}
		return false;
		
	}
	
	public boolean exists ()
	{
		try 
		{
			boolean headerOK = getHeader().equals("Login");
			boolean userOK = usernameField().isDisplayed();
			boolean passwordOK = passwordField().isDisplayed();
			boolean buttonOK = loginButton().isDisplayed();
			
			boolean result =  headerOK & userOK & passwordOK & buttonOK;
			
			return result;
		}
		catch (NoSuchElementException e)
		{
			return false;
		}
	}

}
