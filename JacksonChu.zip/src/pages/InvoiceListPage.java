package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import pages.parts.NavigationBarPart;
import pages.parts.TablePart;

public class InvoiceListPage {
	WebDriver webDriver;
	
	public InvoiceListPage (WebDriver webDriver)
	{
		this.webDriver = webDriver;
	}
	
	private WebElement header ()
	{
		WebElement result = webDriver.findElement(By.xpath("//h2[@class = 'mt-5']"));
				
		return result;
	}
	
	private WebElement navigationBarParent ()
	{
		return webDriver.findElement(By.xpath("//nav[@class = 'navbar navbar-dark bg-dark']"));
	}
	
	private WebElement tableHeaderParent()
	{
		return webDriver.findElement(By.xpath("//div[@class = 'row mt-3 text-light bg-dark']"));
	}
	
	private List<WebElement> tableRowsParent()
	{
		return webDriver.findElements(By.xpath("//div[@class='container']/div[@class = 'row']"));
	}
	
	
	public String getHeader ()
	{
		return header().getText();
	}
	
	public NavigationBarPart bar ()
	{
		
		NavigationBarPart navBar = new NavigationBarPart(navigationBarParent());
		
		return navBar;
	}
	
	public TablePart table()
	{
		return new TablePart(tableHeaderParent(), tableRowsParent());
	}
	
	public void waitLoad (int millis) 
	{
		if (!exists(millis))
		{
			throw new TimeoutException("Invoice List Page did not load after " + millis + " milliseconds.");
		}
	}
	

	public boolean exists (int millis) {
		long end = System.currentTimeMillis() + millis;
		while(System.currentTimeMillis() < end)
		{
			if (exists())
			{
				return true;
			}
			
		}
		return false;
		
	}
	
	public boolean exists () {
		try 
		{
			boolean barOK = bar().exists();
			boolean headerOK = getHeader().equals("Invoice List");
			//TODO tableOK
			
			boolean result =  barOK & headerOK;
			
			return result;
		}
		catch (NoSuchElementException e)
		{
			return false;
		}
	}
	
	
}
