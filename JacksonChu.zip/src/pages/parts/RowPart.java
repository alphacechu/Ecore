package pages.parts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class RowPart {
	WebElement parentElement;
	List<String> headers;
	
	public RowPart(WebElement parentElement, List<String> headers)
	{
		this.parentElement = parentElement;
		this.headers = headers;
	}
	
	private WebElement cell(int index) {
		List<WebElement> cellDivs = parentElement.findElements(By.tagName("div"));

		return cellDivs.get(index);
	}
	
	public String getCell (int index) 
	{
		return cell(index).getText();
	}
	
	public String getCell (String column) 
	{
		int index = headers.indexOf(column);
		return getCell(index);
	}
	
	public void clickCell (int index) 
	{
		WebElement link = cell(index).findElement(By.tagName("a"));
		
		link.click();
	}
	
	public void clickCell (String column) 
	{
		int index = headers.indexOf(column);
		clickCell(index);
	}
}
