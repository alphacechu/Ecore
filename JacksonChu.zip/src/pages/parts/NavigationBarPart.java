package pages.parts;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

public class NavigationBarPart {
	WebElement parentElement;
	
	public NavigationBarPart (WebElement parentElement)
	{
		this.parentElement = parentElement;
		
	}
	
	private WebElement titleSpan ()
	{
		return parentElement.findElement(By.xpath("//span[@class = 'navbar-brand']"));
	}
	
	private WebElement logoutLink ()
	{
		return parentElement.findElement(By.xpath("//li/a[text() = 'Logout']"));
	}
	
	
	public String getTitle ()
	{
		return titleSpan().getText();
	}
	
	public void clickLogout ()
	{
		logoutLink().click();
	}
	
	public boolean exists (int millis) {
		long end = System.currentTimeMillis() + millis;
		while(System.currentTimeMillis() < end)
		{
			if (exists())
			{
				return true;
			}
			
		}
		return false;
		
	}
	
	public boolean exists () {
		try 
		{
			boolean titleOK = getTitle().equals("Automation Example");
			boolean logoutOK = logoutLink().isDisplayed();
			
			boolean result =  titleOK & logoutOK;
			
			return result;
		}
		catch (NoSuchElementException e)
		{
			return false;
		}
	}
	

}
