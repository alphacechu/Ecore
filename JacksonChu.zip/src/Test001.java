import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import workflows.InvoiceWF;
import workflows.LoginWF;

public class Test001 {
	public static WebDriver driver;
	 
	@Test(dataProvider="LoginDataPos")
	public static void Test001_Login_Pos(String username, String password) throws Exception{
		LoginWF login = new LoginWF(driver);
		
		String result = login.login(username, password);
		Assert.assertEquals(result, "Successfully logged in.");
 
	}
	
	@Test(dataProvider="LoginDataNeg")
	public static void Test002_Login_Neg(String username, String password) throws Exception{
		LoginWF login = new LoginWF(driver);
		
		String result = login.login(username, password);
		Assert.assertEquals(result, "Wrong username or password.");
 
	}
	
	@Test(dataProvider="InvoiceData")
	public static void Test003_Invoice_Data(String username, String password, String hotelName, String invoiceDate, String dueDate, String invoiceNumber, String bookingCode, String customerDetails, String room, String checkIn, String checkOut, String totalStayCount, String totalStayAmount, String depositNow, String taxNVAT, String totalAmount) throws Exception{
		LoginWF login = new LoginWF(driver);
		InvoiceWF invoice = new InvoiceWF(driver);
		
		String result = login.login(username, password);
		Assert.assertEquals(result, "Successfully logged in.");
		
		List<String> actualDetails = invoice.getInvoiceDetails(hotelName);
		
		List<String> expectedDetails = new ArrayList<String>();

		expectedDetails.add(hotelName);
		expectedDetails.add(invoiceDate);
		expectedDetails.add(dueDate);
		expectedDetails.add(invoiceNumber);
		expectedDetails.add(bookingCode);
		expectedDetails.add(customerDetails);
		expectedDetails.add(room);
		expectedDetails.add(checkIn);
		expectedDetails.add(checkOut);
		expectedDetails.add(totalStayCount);
		expectedDetails.add(totalStayAmount);
		expectedDetails.add(depositNow);
		expectedDetails.add(taxNVAT);
		expectedDetails.add(totalAmount);
		
		Assert.assertEquals(actualDetails, expectedDetails);
	}
	
	@DataProvider
	private Object[][] LoginDataPos() throws IOException{
		Object[][] data = new Object[1][2];
 
		data[0][0]="demouser";
		data[0][1]="abc123";
 
        return data;
 
	}
	
	@DataProvider
	private Object[][] LoginDataNeg() throws IOException{
		Object[][] data = new Object[4][2];
 
		data[0][0]="Demouser";
		data[0][1]="abc123";
		
		data[1][0]="demouser_";
		data[1][1]="xyz";
		
		data[2][0]="demouser";
		data[2][1]="nananana";
		
		data[3][0]="Demouser";
		data[3][1]="abc123";
		
	 
	    return data;
 
	}
	
	@DataProvider
	private Object[][] InvoiceData() throws IOException{
		Object[][] data = new Object[1][16];
 
		data[0][0]="demouser";
		data[0][1]="abc123";
		data[0][2]="Rendezvous Hotel";
		data[0][3]="14/01/2018";
		data[0][4]="15/01/2018";
		data[0][5]="110";
		data[0][6]="0875";
		data[0][7]="JOHNY SMITH\nR2, AVENUE DU MAROC\n123456";
		data[0][8]="Superior Double";
		data[0][9]="14/01/2018";
		data[0][10]="15/01/2018";
		data[0][11]="1";
		data[0][12]="$150";
		data[0][13]="USD $20.90";
		data[0][14]="USD $19.00";
		data[0][15]="USD $209.00";

 
        return data;
 
	}
 
	@BeforeMethod
	private void launch() {
		// Launch application url
		driver = new ChromeDriver();
		driver.navigate().to("https://automation-sandbox.herokuapp.com/");
 
	}
 
	  @AfterMethod
	  private void close() {
		  //Close driver
		  driver.quit();
 
	  }
}
