package pages.parts;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class TablePart {
	WebElement headerParent;
	List<WebElement> rowsParents;

	public TablePart (WebElement headerParent, List<WebElement> rowsParents)
	{
		this.headerParent = headerParent;
		this.rowsParents = rowsParents;
	}
	
	public List<String> headers()
	{
		List<WebElement> divs = headerParent.findElements(By.tagName("div"));
		List<String> result = new ArrayList<String>();
		
		for(WebElement eachDiv : divs)
		{
			String divText = eachDiv.getText();
			result.add(divText);
		}
		
		return result;
	}
	
	public RowPart row(int index)
	{	
		return new RowPart(rowsParents.get(index), headers());
	}
	
	public RowPart row(int column, String value) throws Exception
	{	
		for (WebElement eachRow :rowsParents) {
			RowPart rowPart = new RowPart(eachRow, headers()); 
			if (rowPart.getCell(column).equals(value))
			{
				return rowPart;
			}
		}
		
		throw new Exception("No row matching '" + value +"' value in column '" + column + "'.");
	}
	
	public RowPart row(String column, String value) throws Exception
	{
		int index = headers().indexOf(column);
		return row(index,value);
	}
}
