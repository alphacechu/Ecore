package pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import pages.parts.NavigationBarPart;

public class InvoiceDetailsPage {
	WebDriver webDriver;
	
	public InvoiceDetailsPage(WebDriver webDriver)
	{
		this.webDriver = webDriver;
	}
	
	private WebElement header ()
	{
		WebElement result = webDriver.findElement(By.xpath("//h2[@class = 'mt-5']"));
				
		return result;
	}
	
	private WebElement navigationBarParent ()
	{
		return webDriver.findElement(By.xpath("//nav[@class = 'navbar navbar-dark bg-dark']"));
	}
	
	private WebElement hotelElement()
	{
		return webDriver.findElement(By.xpath("//h4[@class='mt-5']"));
	}
	
	private WebElement invoiceDateElement()
	{
		return webDriver.findElement(By.xpath("//li[span[text()='Invoice Date:']]"));
	}
	
	private WebElement dueDateElement()
	{
		return webDriver.findElement(By.xpath("//li[span[text()='Due Date:']]"));
	}
	
	private WebElement invoiceNumberElement()
	{
		return webDriver.findElement(By.xpath("//h6[@class='mt-2'][contains(text(),'Invoice')]"));
	}
	
	private WebElement bookingCodeElement()
	{
		return webDriver.findElement(By.xpath("//td[text()='Booking Code']/following-sibling::td"));
	}
	
	private WebElement customerDetailsElement()
	{
		return webDriver.findElement(By.xpath("//h5[text()='Customer Details']/following-sibling::div"));
	}
	
	private WebElement roomElement()
	{
		return webDriver.findElement(By.xpath("//td[text()='Room']/following-sibling::td"));
	}
	
	private WebElement checkInElement()
	{
		return webDriver.findElement(By.xpath("//td[text()='Check-In']/following-sibling::td"));
	}
	
	private WebElement checkOutElement()
	{
		return webDriver.findElement(By.xpath("//td[text()='Check-Out']/following-sibling::td"));
	}
	
	private WebElement totalStayCountElement()
	{
		return webDriver.findElement(By.xpath("//td[text()='Total Stay Count']/following-sibling::td"));
	}
	
	private WebElement totalStayAmountElement()
	{
		return webDriver.findElement(By.xpath("//td[text()='Total Stay Amount']/following-sibling::td"));
	}
	
	private WebElement depositNowElement()
	{
		return webDriver.findElement(By.xpath("//h5[@class='mt-5'][text()='Billing Details']/following-sibling::table/tbody/tr/td[1]"));
	}
	
	private WebElement taxNVatElement()
	{
		return webDriver.findElement(By.xpath("//h5[@class='mt-5'][text()='Billing Details']/following-sibling::table/tbody/tr/td[2]"));
	}
	
	private WebElement totalAmountElement()
	{
		return webDriver.findElement(By.xpath("//h5[@class='mt-5'][text()='Billing Details']/following-sibling::table/tbody/tr/td[3]"));
	}
	
	public String getHeader ()
	{
		return header().getText();
	}
	
	public NavigationBarPart bar ()
	{
		
		NavigationBarPart navBar = new NavigationBarPart(navigationBarParent());
		
		return navBar;
	}
	
	public String getHotelName()
	{
		return hotelElement().getText();
	}
	
	public String getInvoiceDate()
	{
		String result = invoiceDateElement().getText().replaceAll("Invoice Date: ", "");
		return result;
	}
	
	public String getDueDate()
	{
		return dueDateElement().getText().replaceAll("Due Date: ", "");
	}
	
	public String getInvoiceNumber()
	{
		return invoiceNumberElement().getText().replaceAll("Invoice #", "").replaceAll(" details", "");
	}
	
	public String getBookingCode()
	{
		return bookingCodeElement().getText();
	}
	
	public String getCustomerDetails()
	{
		return customerDetailsElement().getText();
	}
	
	public String getRoom()
	{
		return roomElement().getText();
	}
	
	public String getCheckIn()
	{
		return checkInElement().getText();
	}
	
	public String getCheckOut()
	{
		return checkOutElement().getText();
	}
	
	public String getTotalStayCount()
	{
		return totalStayCountElement().getText();
	}
	
	public String getTotalStayAmount()
	{
		return totalStayAmountElement().getText();
	}
	
	public String getDepositNow()
	{
		return depositNowElement().getText();
	}
	
	public String getTaxNVat()
	{
		return taxNVatElement().getText();
	}
	
	public String getTotalAmount()
	{
		return totalAmountElement().getText();
	}
	
	public void waitLoad (int millis) 
	{
		if (!exists(millis))
		{
			throw new TimeoutException("Invoice Details Page did not load after " + millis + " milliseconds.");
		}
	}
	

	public boolean exists (int millis) {
		long end = System.currentTimeMillis() + millis;
		while(System.currentTimeMillis() < end)
		{
			if (exists())
			{
				return true;
			}
			
		}
		return false;
		
	}
	
	public boolean exists () {
		try 
		{
			ArrayList<String> tabs = new ArrayList<String> (webDriver.getWindowHandles());
			webDriver.switchTo().window(tabs.get(1));
			
			boolean barOK = bar().exists();
			boolean headerOK = getHeader().equals("Invoice Details");
			
			boolean result =  barOK & headerOK;
			
			return result;
		}
		catch (NoSuchElementException e)
		{
			return false;
		}
	}

	
}
