package workflows;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;

import pages.InvoiceDetailsPage;
import pages.InvoiceListPage;

public class InvoiceWF {
	WebDriver webDriver;
	
	public InvoiceWF(WebDriver webDriver)
	{
		this.webDriver = webDriver;
	}
	
	public List<String> getInvoiceDetails(String hotelName) throws Exception
	{
		InvoiceListPage list = new InvoiceListPage(webDriver);
		InvoiceDetailsPage details = new InvoiceDetailsPage(webDriver);
		List<String> result = new ArrayList<String>();
		
		list.table().row("Hotel Name", hotelName).clickCell("Invoice Link");
		details.waitLoad(10000);

		result.add(details.getHotelName());
		result.add(details.getInvoiceDate());
		result.add(details.getDueDate());
		result.add(details.getInvoiceNumber());
		result.add(details.getBookingCode());
		result.add(details.getCustomerDetails());
		result.add(details.getRoom());
		result.add(details.getCheckIn());
		result.add(details.getCheckOut());
		result.add(details.getTotalStayCount());
		result.add(details.getTotalStayAmount());
		result.add(details.getDepositNow());
		result.add(details.getTaxNVat());
		result.add(details.getTotalAmount());
		
		return result;
	}

}
